import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../shared/text_input_formatters.dart';
import '../../shared/web_colors.dart';

class IdentityProfessionalSection extends StatefulWidget {
  const IdentityProfessionalSection({
    super.key,
    required this.user,
    this.requestId,
    this.readOnly = false,
    this.onSaved,
  });

  final User? user;
  final String? requestId;
  final bool readOnly;
  final VoidCallback? onSaved;

  @override
  State<IdentityProfessionalSection> createState() =>
      _IdentityProfessionalSectionState();
}

class _IdentityProfessionalSectionState
    extends State<IdentityProfessionalSection> {
  final _formKey = GlobalKey<FormState>();
  final _lastNameController = TextEditingController();
  final _firstNameController = TextEditingController();
  final _functionController = TextEditingController();
  final _phoneController = TextEditingController();
  final _professionalEmailController = TextEditingController();
  String? _civility;
  final _civilityLink = LayerLink();
  final _civilityKey = GlobalKey();
  OverlayEntry? _civilityOverlay;

  bool _loading = true;
  bool _saving = false;
  bool _completed = false;
  bool _requestExists = false;
  String? _error;

  String? get _requestId {
    final value = widget.requestId?.trim() ?? '';
    if (value.isNotEmpty) return value;
    return widget.user?.uid;
  }

  @override
  void initState() {
    super.initState();
    _initialiseProfile();
  }

  @override
  void dispose() {
    _closeCivilityMenu();
    _lastNameController.dispose();
    _firstNameController.dispose();
    _functionController.dispose();
    _phoneController.dispose();
    _professionalEmailController.dispose();
    super.dispose();
  }

  Future<void> _initialiseProfile() async {
    final user = widget.user;
    final requestId = _requestId;
    _professionalEmailController.text = user?.email ?? '';

    if (requestId != null) {
      _prefillDisplayName(user?.displayName);

      try {
        final snapshot = await FirebaseFirestore.instance
            .collection('advertiserRequests')
            .doc(requestId)
            .get();
        final data = snapshot.data();
        _requestExists = snapshot.exists;

        if (data != null) {
          final storedCivility = _textValue(
            data['contactCivility'] ?? data['civilite'],
          );
          if (storedCivility.isNotEmpty) {
            _civility = storedCivility;
          }
          _lastNameController.text = _textValue(
            data['contactLastName'],
            _lastNameController.text,
          ).toUpperCase();
          _firstNameController.text = capitalizeFirstLetter(
            _textValue(data['contactFirstName'], _firstNameController.text),
          );
          _functionController.text = capitalizeFirstLetter(
            _textValue(data['contactFunction']),
          );
          _phoneController.text = _PhoneNumberInputFormatter.format(
            _textValue(data['contactPhone']),
          );
          _professionalEmailController.text = _textValue(
            data['contactEmail'],
            _professionalEmailController.text,
          );
          _completed = data['profileCompleted'] == true || _fieldsAreComplete;
        }
      } catch (error) {
        _error = 'Impossible de charger les informations enregistrées.';
        debugPrint('Chargement identité annonceur impossible : $error');
      }
    }

    if (!mounted) return;
    setState(() => _loading = false);
  }

  String _textValue(Object? value, [String fallback = '']) {
    final text = value?.toString().trim() ?? '';
    return text.isEmpty ? fallback : text;
  }

  void _prefillDisplayName(String? displayName) {
    final parts = (displayName ?? '')
        .trim()
        .split(RegExp(r'\s+'))
        .where((part) => part.isNotEmpty)
        .toList();

    if (parts.isEmpty) return;
    _firstNameController.text = capitalizeFirstLetter(parts.first);
    if (parts.length > 1) {
      _lastNameController.text = parts.skip(1).join(' ').toUpperCase();
    }
  }

  bool get _fieldsAreComplete {
    return (_civility?.trim().isNotEmpty ?? false) &&
        _lastNameController.text.trim().isNotEmpty &&
        _firstNameController.text.trim().isNotEmpty &&
        _functionController.text.trim().isNotEmpty &&
        _phoneController.text.trim().isNotEmpty &&
        _professionalEmailController.text.trim().isNotEmpty;
  }

  Future<void> _save() async {
    if (widget.readOnly) return;
    FocusScope.of(context).unfocus();
    if (!(_formKey.currentState?.validate() ?? false)) return;

    setState(() {
      _saving = true;
      _error = null;
    });

    try {
      final user = widget.user;
      final requestId = _requestId;
      final civility = _civility!.trim();
      final lastName = forceUpperCase(_lastNameController.text.trim());
      final firstName = capitalizeFirstLetter(_firstNameController.text.trim());
      final contactFunction = capitalizeFirstLetter(
        _functionController.text.trim(),
      );
      final contactEmail = _professionalEmailController.text.trim();

      _lastNameController.text = lastName;
      _firstNameController.text = firstName;
      _functionController.text = contactFunction;

      if (requestId != null) {
        final creationData = _requestExists
            ? <String, Object?>{}
            : <String, Object?>{
                'status': 'draft',
                'createdAt': FieldValue.serverTimestamp(),
              };

        await FirebaseFirestore.instance
            .collection('advertiserRequests')
            .doc(requestId)
            .set({
              ...creationData,
              'uid': requestId,
              'email': user?.email ?? contactEmail,
              'displayName': user?.displayName ?? '$firstName $lastName',
              'contactName': '$firstName $lastName'.trim(),
              'contactCivility': civility,
              'civilite': civility,
              'contactFirstName': firstName,
              'contactLastName': lastName,
              'contactFunction': contactFunction,
              'contactPhone': _phoneController.text.trim(),
              'contactEmail': contactEmail,
              'profileCompleted': true,
              'updatedAt': FieldValue.serverTimestamp(),
            }, SetOptions(merge: true));
        _requestExists = true;
      }

      if (!mounted) return;
      setState(() => _completed = true);
      widget.onSaved?.call();
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = 'L’enregistrement a échoué. Réessayez.');
      debugPrint('Enregistrement identité annonceur impossible : $error');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  String? _requiredValidator(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Champ obligatoire';
    }
    return null;
  }

  String? _emailValidator(String? value) {
    final requiredError = _requiredValidator(value);
    if (requiredError != null) return requiredError;

    final email = value!.trim();
    final valid = RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(email);
    return valid ? null : 'Adresse email invalide';
  }

  void _profileChanged(String _) {
    if (_completed) setState(() => _completed = false);
  }

  void _closeCivilityMenu() {
    _civilityOverlay?.remove();
    _civilityOverlay = null;
  }

  void _openCivilityMenu(FormFieldState<String> field) {
    if (widget.readOnly) return;
    if (_civilityOverlay != null) {
      _closeCivilityMenu();
      return;
    }
    final box = _civilityKey.currentContext?.findRenderObject();
    if (box is! RenderBox) return;
    final width = box.size.width;
    _civilityOverlay = OverlayEntry(
      builder: (_) => Stack(
        children: [
          Positioned.fill(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: _closeCivilityMenu,
            ),
          ),
          CompositedTransformFollower(
            link: _civilityLink,
            showWhenUnlinked: false,
            targetAnchor: Alignment.bottomLeft,
            followerAnchor: Alignment.topLeft,
            offset: const Offset(0, -12),
            child: SizedBox(
              width: width,
              child: Material(
                color: Colors.transparent,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.97),
                    border: const Border(
                      left: BorderSide(color: WebColors.blue, width: 1.4),
                      right: BorderSide(color: WebColors.blue, width: 1.4),
                      bottom: BorderSide(color: WebColors.blue, width: 1.4),
                    ),
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(10),
                      bottomRight: Radius.circular(10),
                    ),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 8,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      for (final choice in ['Monsieur', 'Madame'])
                        InkWell(
                          onTap: () {
                            field.didChange(choice);
                            setState(() {
                              _civility = choice;
                              _completed = false;
                            });
                            _closeCivilityMenu();
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 10,
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    choice,
                                    style: const TextStyle(
                                      color: WebColors.blue,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ),
                                if (_civility == choice)
                                  const Icon(
                                    Icons.check_rounded,
                                    color: WebColors.red,
                                    size: 20,
                                  ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
    Overlay.of(context, rootOverlay: true).insert(_civilityOverlay!);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 48),
        child: Center(child: CircularProgressIndicator(color: WebColors.red)),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (widget.readOnly)
          const _SectionCard(
            icon: Icons.lock_outline_rounded,
            title: 'PROFIL VALIDÉ PAR SPHOT',
            status: 'LECTURE SEULE',
            statusColor: Color(0xFF15803D),
            child: Text(
              'Ces informations ont servi à valider votre accès annonceur.',
              style: TextStyle(
                color: WebColors.blue,
                fontWeight: FontWeight.w700,
                height: 1.35,
              ),
            ),
          ),
        _SectionCard(
          icon: Icons.badge_outlined,
          title: 'PROFIL PROFESSIONNEL SPHOT',
          status: _completed ? 'COMPLET' : 'À COMPLÉTER',
          statusColor: _completed ? WebColors.red : const Color(0xFF6B7280),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: FormField<String>(
                    initialValue: _civility,
                    validator: _requiredValidator,
                    builder: (field) => CompositedTransformTarget(
                      link: _civilityLink,
                      child: GestureDetector(
                        key: _civilityKey,
                        onTap: widget.readOnly
                            ? null
                            : () => _openCivilityMenu(field),
                        child: InputDecorator(
                          decoration: InputDecoration(
                            labelText: 'Civilité *',
                            labelStyle: const TextStyle(color: WebColors.blue),
                            errorText: field.errorText,
                            filled: true,
                            fillColor: const Color(0xFFF8FAFC),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 16,
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                color: WebColors.blue,
                                width: 1.6,
                              ),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                color: WebColors.blue,
                                width: 1.6,
                              ),
                            ),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  _civility ?? 'Sélectionnez une civilité',
                                  style: const TextStyle(
                                    color: WebColors.blue,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                              const Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color: WebColors.red,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                _ProfileField(
                  controller: _lastNameController,
                  label: 'Nom *',
                  validator: _requiredValidator,
                  onChanged: _profileChanged,
                  readOnly: widget.readOnly,
                  textCapitalization: TextCapitalization.characters,
                  inputFormatters: const [UpperCaseTextInputFormatter()],
                ),
                _ProfileField(
                  controller: _firstNameController,
                  label: 'Prénom *',
                  validator: _requiredValidator,
                  onChanged: _profileChanged,
                  readOnly: widget.readOnly,
                  textCapitalization: TextCapitalization.sentences,
                  inputFormatters: const [
                    FirstLetterUpperCaseTextInputFormatter(),
                  ],
                ),
                _ProfileField(
                  controller: _functionController,
                  label: 'Fonction *',
                  validator: _requiredValidator,
                  onChanged: _profileChanged,
                  readOnly: widget.readOnly,
                  textCapitalization: TextCapitalization.sentences,
                  inputFormatters: const [
                    FirstLetterUpperCaseTextInputFormatter(),
                  ],
                ),
                _ProfileField(
                  controller: _phoneController,
                  label: 'Téléphone professionnel *',
                  keyboardType: TextInputType.phone,
                  inputFormatters: const [_PhoneNumberInputFormatter()],
                  validator: _requiredValidator,
                  onChanged: _profileChanged,
                  readOnly: widget.readOnly,
                ),
                _ProfileField(
                  controller: _professionalEmailController,
                  label: 'Email professionnel *',
                  keyboardType: TextInputType.emailAddress,
                  validator: _emailValidator,
                  onChanged: _profileChanged,
                  readOnly: widget.readOnly,
                ),
                if (!widget.readOnly) const SizedBox(height: 4),
                if (!widget.readOnly)
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: FilledButton.icon(
                      onPressed: _saving ? null : _save,
                      style: FilledButton.styleFrom(
                        backgroundColor: _completed
                            ? WebColors.red
                            : WebColors.blue,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      icon: _saving
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                            )
                          : Icon(
                              _completed
                                  ? Icons.check_circle_outline_rounded
                                  : Icons.save_outlined,
                            ),
                      label: Text(
                        _saving
                            ? 'ENREGISTREMENT…'
                            : _completed
                            ? 'IDENTITÉ PROFESSIONNELLE ENREGISTRÉE'
                            : 'ENREGISTRER L’IDENTITÉ PROFESSIONNELLE',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              _error!,
              style: const TextStyle(
                color: WebColors.red,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
      ],
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.icon,
    required this.title,
    required this.status,
    required this.child,
    this.statusColor = const Color(0xFF6B7280),
  });

  final IconData icon;
  final String title;
  final String status;
  final Widget child;
  final Color statusColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFCBD5E1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: WebColors.blue, size: 30),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: WebColors.blue,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      status,
                      style: TextStyle(
                        color: statusColor,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }
}

class _ProfileField extends StatelessWidget {
  const _ProfileField({
    required this.controller,
    required this.label,
    required this.validator,
    required this.onChanged,
    this.keyboardType,
    this.inputFormatters,
    this.readOnly = false,
    this.textCapitalization = TextCapitalization.none,
  });

  final TextEditingController controller;
  final String label;
  final TextInputType? keyboardType;
  final List<TextInputFormatter>? inputFormatters;
  final String? Function(String?) validator;
  final ValueChanged<String> onChanged;
  final bool readOnly;
  final TextCapitalization textCapitalization;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        inputFormatters: inputFormatters,
        textCapitalization: textCapitalization,
        validator: validator,
        onChanged: onChanged,
        readOnly: readOnly,
        style: const TextStyle(
          color: WebColors.blue,
          fontWeight: FontWeight.w700,
        ),
        autovalidateMode: AutovalidateMode.onUserInteraction,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: Color(0xFF4B5F97)),
          filled: true,
          fillColor: const Color(0xFFF8FAFC),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFFCBD5E1)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFFCBD5E1)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: WebColors.blue, width: 2),
          ),
        ),
      ),
    );
  }
}

class _PhoneNumberInputFormatter extends TextInputFormatter {
  const _PhoneNumberInputFormatter();

  static String format(String input) {
    final trimmed = input.trim();
    final hasInternationalPrefix = trimmed.startsWith('+');
    var digits = input.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.length > 15) digits = digits.substring(0, 15);

    final groups = <String>[];
    for (var index = 0; index < digits.length; index += 2) {
      final end = index + 2 < digits.length ? index + 2 : digits.length;
      groups.add(digits.substring(index, end));
    }
    final formatted = groups.join(' ');
    if (formatted.isEmpty) return hasInternationalPrefix ? '+' : '';
    return hasInternationalPrefix ? '+$formatted' : formatted;
  }

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final formatted = format(newValue.text);
    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }
}
